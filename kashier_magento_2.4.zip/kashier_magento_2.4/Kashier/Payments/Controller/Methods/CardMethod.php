<?php
namespace Kashier\Payments\Controller\Methods;

/**
 * Card Payment Method
 */
use Kashier\Payments\Helper\Kashier;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Sales\Model\Order;
use Magento\Framework\App\ResourceConnection;
use Kashier\Payments\Model\Card;
use Magento\Framework\App\Action\Context;

class CardMethod extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface
{
    protected $resultFactory;
    protected $order;
    protected $resource;
    protected $card;
    protected $response;

    // Gateway unique options
    protected $api_id;
    protected $api_has_delivery;
    protected $api_handles_shipping_fees;
    public function __construct(
        Context $context,
        Order $order,
        ResourceConnection $resource,
        Card $card
    )
    {
        parent::__construct($context);
        $this->resultFactory = $context->getResultFactory();
        $this->order = $order;
        $this->resource = $resource;
        $this->card = $card;

        // Gateway unique options
        $this->api_id = "CARD";
        $this->api_has_delivery = false;
        $this->api_handles_shipping_fees = true;
    }
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
	}
    public function execute()
    {
        $this->response = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_JSON);
        $this->response->setHttpResponseCode(200);
        $order_id = $this->getRequest()->getContent();
        // dd($this->getRequest());

        try{
            $order = $this->order->load($order_id);

            if($order){

                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                
                $store         =  $objectManager->get(\Magento\Store\Model\StoreManagerInterface::class)
                                                ->getStore();

                $callback_url  = $store->getBaseUrl() . 'kashier/callback/card';

                $storeName     = $store->getName();

                $storeLanguage = $objectManager->get('Magento\Framework\Locale\Resolver')
                                               ->getLocale();
                                
                $lang          = strpos( $storeLanguage , 'ar' ) !== false ? 'ar' : 'en' ;
                
                $mode          = $this->card->getConfigData('mode') == '0' ? 'live' : 'test';

                $api_key       = $mode == 'live' ? $this->card->getConfigData('live_api_key') : $this->card->getConfigData('test_api_key');

                // config to be sent to the Kashier helper.
                $config = [
                    "api_key" => $api_key,
                    "merchantId" => $this->card->getConfigData('merchant_id'),
                    "handles_shipping" => $this->api_handles_shipping_fees,
                    "has_delivery" => $this->api_has_delivery,
                ];

                // Start a helper instance
                $helper = new Kashier($order, $config);                
            
            }else {
                throw new \Exception("<p><b>Fatal Error:</b> Order with the id of ($order_id) was not found!</p>");
            }

            $order->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)
                  ->setStatus(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)
                  ->addStatusHistoryComment( __("Order Created: Awaiting payment") )
                  ->save();

            $this->response->setData([
                'success'     => true,
                'merchantId'  => $helper->merchantId,
                'orderId'     => $helper->orderId,
                'currency'    => $helper->currency,
                'amount'      => $helper->amount,
                'hash'        => $helper->hash,
                'metaData'    => $helper->metaData,
                'urlCallBack' => $callback_url,
                'store'       => $storeName,
                'mode'        => $mode,
                'lang'        => $lang  
            ]);

        } catch (\Exception $e) {
            $this->response->setData([
                'success' => false,
                'detail' => $e->getMessage(),
            ]);
        }

        return $this->response;
    }
}