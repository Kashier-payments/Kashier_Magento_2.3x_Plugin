<?php
namespace Kashier\Payments\Model;

use Magento\Payment\Model\Method\AbstractMethod;

class installments extends AbstractMethod
{
    const CODE = "installments";

    protected $_code = self::CODE;
    protected $_isGateway = true;
    protected $_canCapture = false;
    protected $_canCapturePartial = false;
    protected $_canRefund = false;
    protected $_canRefundInvoicePartial = false;
}
