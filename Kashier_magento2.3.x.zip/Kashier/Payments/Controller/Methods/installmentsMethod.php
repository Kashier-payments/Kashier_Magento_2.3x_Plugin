<?php
namespace Kashier\Payments\Controller\Methods;

/**
 * installments Payment Method
 */
use Kashier\Payments\Helper\Kashier;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\InvalidRequestException;

class installmentsMethod extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Sales\Model\Order $order,
        \Magento\Framework\App\ResourceConnection $resource,
        \Kashier\Payments\Model\installments $installments
    )
    {
        parent::__construct($context);
        $this->resultFactory = $context->getResultFactory();
        $this->order = $order;
        $this->resource = $resource;
        $this->installments = $installments;

        // Gateway unique options
        $this->api_id = "installments";
        $this->api_has_delivery = false;
        $this->api_handles_shipping_fees = true;
    }
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
	}
    public function execute()
    {
        $this->response = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_JSON);
        $this->response->setHttpResponseCode(200);
        $order_id = $this->getRequest()->getContent();

        try{
            $order = $this->order->load($order_id);

            if($order){

                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                
                $store         =  $objectManager->get(\Magento\Store\Model\StoreManagerInterface::class)
                                                ->getStore();

                $callback_url  = $store->getBaseUrl() . 'kashier/callback/installments';

                $storeName     = $store->getName();

                $storeLanguage = $objectManager->get('Magento\Framework\Locale\Resolver')
                                               ->getLocale();
                                
                $lang          = strpos( $storeLanguage , 'ar' ) !== false ? 'ar' : 'en' ;
                
                $mode          = $this->installments->getConfigData('mode') == 0 ? 'live' : 'test';

                $api_key       = $mode == '0' ? $this->installments->getConfigData('live_api_key') : $this->installments->getConfigData('test_api_key');

                // config to be sent to the Kashier helper.
                $config = [
                    "api_key" => $api_key,
                    "merchantId" => $this->installments->getConfigData('merchant_id'),
                    "handles_shipping" => $this->api_handles_shipping_fees,
                    "has_delivery" => $this->api_has_delivery,
                ];

                // Start a helper instance
                $helper = new Kashier($order, $config);                
            
            }else {
                throw new \Exception("<p><b>Fatal Error:</b> Order with the id of ($order_id) was not found!</p>");
            }

            $order->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)
                  ->setStatus(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)
                  ->addStatusHistoryComment( __("Order Created: Awaiting payment") )
                  ->save();

            $this->response->setData([
                'success'     => true,
                'merchantId'  => $helper->merchantId,
                'orderId'     => $helper->orderId,
                'currency'    => $helper->currency,
                'amount'      => $helper->amount,
                'hash'        => $helper->hash,
                'metaData'    => $helper->metaData,
                'urlCallBack' => $callback_url,
                'store'       => $storeName,
                'mode'        => $mode,
                'lang'        => $lang  
            ]);

        } catch (\Exception $e) {
            $this->response->setData([
                'success' => false,
                'detail' => $e->getMessage(),
            ]);
        }

        return $this->response;
    }
}