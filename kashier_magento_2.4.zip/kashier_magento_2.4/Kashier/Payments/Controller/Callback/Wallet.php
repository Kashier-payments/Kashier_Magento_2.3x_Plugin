<?php
namespace Kashier\Payments\Controller\Callback;

use Kashier\Payments\Helper\Notify;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\InvalidRequestException;

class Wallet extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface {

	protected $context;
	protected $order;
	protected $invoice;
	protected $resultFactory;
	protected $base_url;
	protected $website_id;
	protected $resource;
	protected $customer;
	protected $wallet;
	protected $creditmemoFactory;
	protected $creditmemoService;

    public function __construct(
		\Magento\Framework\App\Action\Context $context, 
		\Magento\Sales\Model\Order $order,
		\Magento\Sales\Model\Service\InvoiceService $invoice,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\App\ResourceConnection $resource,
		\Magento\Customer\Model\Customer $customer,
		\Kashier\Payments\Model\Wallet $wallet,
		\Magento\Sales\Model\Order\CreditmemoFactory $creditmemoFactory,
		\Magento\Sales\Model\Service\CreditmemoService $creditmemoService
    )
    {
			parent::__construct($context);
			$this->context = $context;
			$this->order = $order;
			$this->invoice = $invoice;
			$this->resultFactory = $context->getResultFactory();
			$this->base_url = $storeManager->getStore()->getBaseUrl();
			$this->website_id = $storeManager->getStore()->getWebsiteId();
			$this->resource = $resource;
			$this->customer = $customer;
			$this->wallet = $wallet;
			$this->creditmemoFactory = $creditmemoFactory;
			$this->creditmemoService = $creditmemoService;
	}
	
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
	}

    public function execute() {
		try{
			$mode          = $this->wallet->getConfigData('mode') == '0' ? 'live' : 'test';

			$api_key       = $mode == 'live' ? $this->wallet->getConfigData('live_api_key') : $this->wallet->getConfigData('test_api_key');

			$ping = new Notify(
				$this->order,
				$this->invoice,
				$this->resultFactory,
				$this->resource,
				$this->customer,
				$this->messageManager,
				$this->base_url,
				$this->website_id,
				$api_key,
				$this->creditmemoFactory,
				$this->creditmemoService
			);
			return $ping->Pong($this->getRequest()->getContent());
			
		}catch (\Exception $e){
			\var_dump($e);
			die(1);
		}

	}
}