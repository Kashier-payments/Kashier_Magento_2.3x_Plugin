define(
    [
        'Magento_Checkout/js/view/payment/default',
        'jquery',
        'Magento_Checkout/js/model/payment/additional-validators',
        'mage/url',
        'Magento_Checkout/js/action/place-order',
        'Magento_Checkout/js/model/full-screen-loader'
    ],
    function (
        Component,
        $,
        additionalValidators,
        url,
        placeOrderAction,
        fullScreenLoader
    ) {
        return Component.extend({
            defaults: {
                template: 'Kashier_Payments/payment/installments',
                success: false,
                detail: null
            },
            afterPlaceOrder: function (data, event) {
                var self = this;
                fullScreenLoader.startLoader();
                $.ajax({
                    type: 'POST',
                    url: url.build('kashier/methods/walletmethod'),
                    data: data,
                    success: function (response) {
                        if (response.success) {
                            console.log("afterPlaceOrder:success");
                            console.log(response)
                            self.renderPayment(response);
                        } else {
                            console.log("afterPlaceOrder:error");
                            console.log(response)
                            self.renderErrors(response);
                        }
                    },
                    error: function (response) {
                        console.log("afterPlaceOrder:error");
                        console.log(response)
                        fullScreenLoader.stopLoader();
                        self.renderErrors(response);
                    }
                });
            },
            placeOrder: function (data, event) {
                if (event) {
                    event.preventDefault();
                }
                this._init3DsListener();
                if (additionalValidators.validate()) {
                    placeOrder = placeOrderAction(
                        this.getData(),
                        false,
                        this.messageContainer
                    );
                    console.log('before');
                    $.when(placeOrder).done(this.afterPlaceOrder.bind(this));
                    console.log('after');
                    return true;
                }

                return false;
            },
            renderPayment: function (data) {
                $("body").append(`<div id='iframe-container' style="display:none">
                                              <script id="kashier-iFrame"
                                                      src="https://checkout.kashier.io/kashier-checkout.js" 
                                                      data-description="description"
                                                      data-amount=${data.amount}
                                                      data-hash=${data.hash}
                                                      data-currency=${data.currency}
                                                      data-orderId=${data.orderId}
                                                      data-merchantId=${data.merchantId}
                                                      data-merchantRedirect=${data.urlCallBack}
                                                      data-metaData=${data.metaData}
                                                      data-store="${data.store}"
                                                      data-display=${data.lang}
                                                      data-mode=${data.mode}
                                                      data-allowedMethods='wallet'
                                                      data-failureRedirect="true"
                                                      data-type="external"
                                                >
                                              </script>
                                    </div>`
                );


                this._init3DsListener(data);
                this.clickButton();
                
            },
            renderErrors: function (data) {
                fullScreenLoader.stopLoader();
                $('body').css({
                    'overflow': 'hidden'
                });

                $('#online-za').show(250, function(){
                    $('#online-errors').show(250, function(){
                        $('#online-errors .errors').show().html(data.detail);
                    });
                });
            },
            clickButton: function () {
                var self = this;
                if($('#el-kashier-button')[0]){
                    console.log($('#el-kashier-button'));
                    fullScreenLoader.stopLoader();
                    $('#el-kashier-button').click();
                } else {
                    setTimeout(function(){
                        self.clickButton()
                    }, 1000);
                }
            },
            _init3DsListener: function (data) {
                var self = this;
                if (window.addEventListener) {
                  addEventListener(
                    'message',
                    function(e){
                        self._3DsFrameMessageListener(e,data)
                    },
                    false
                  );
                } else {
                  attachEvent(
                      'onmessage', 
                       function(e){
                               self._3DsFrameMessageListener(e,data)
                       });
                }
          
              },
              _3DsFrameMessageListener: function (e,data) {
                var iFrameMessage = e.data ? e.data : e;

                if (iFrameMessage.message == 'closeIframe') {
                    window.location = `${data.urlCallBack}?paymentStatus=closeIframe&merchantOrderId=${data.orderId}`;
                } 
              },
            getData: function () {
                return {"method": this.item.method};
            },
        });
    }
);
