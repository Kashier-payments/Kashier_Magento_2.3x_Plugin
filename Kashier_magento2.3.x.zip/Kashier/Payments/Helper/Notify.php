<?php
namespace Kashier\Payments\Helper;

class Notify{
    public function __construct(
		\Magento\Sales\Model\Order $order,
		\Magento\Sales\Model\Service\InvoiceService $invoice,
		\Magento\Framework\Controller\ResultFactory $resultFactory,
		\Magento\Framework\App\ResourceConnection $resource,
		\Magento\Customer\Model\Customer $customer,
		$messageManager, $base_url, $website_id, $api_key,
		\Magento\Sales\Model\Order\CreditmemoFactory $creditmemoFactory,
		\Magento\Sales\Model\Service\CreditmemoService $creditmemoService
    )
    {
			$this->order = $order;
			$this->invoice = $invoice;
			$this->resultFactory = $resultFactory;
			$this->resource = $resource;
			$this->customer = $customer;
			$this->messageManager = $messageManager;
			$this->base_url = $base_url;
			$this->website_id = $website_id;
			$this->api_key = $api_key;
			$this->creditmemoFactory = $creditmemoFactory;
			$this->creditmemoService = $creditmemoService;
	}
	
	/**
	 * Shared function all incoming notifications pass through here.
	 * Usage: ping → pong 
	 */
    public function Pong($request_data) {
		try{

		    if ($_SERVER['REQUEST_METHOD'] === "GET") {
				$data = $_GET;
			}

			if ($_SERVER['REQUEST_METHOD'] === "GET" && $data['paymentStatus'] == 'closeIframe' && !isset($_GET['signature']) ) {
				$response = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);

				$order_id = substr($data['merchantOrderId'], 0, -11);
				$order = $this->order->load($order_id);
				
				if(!$order){
					die("Fatal Error: Order with the id of ($order_id) was not found!");
				}

				// ready to invoice
				$already_invoiced = false;
				foreach ($order->getInvoiceCollection() as $invoice) {
						if($invoice->getGrandTotal() == $order->getGrandTotal()){
								$already_invoiced = true;
						}
				}

				$order->setState(\Magento\Sales\Model\Order::STATE_CANCELED )
					->setStatus(\Magento\Sales\Model\Order::STATE_CANCELED )->save();

				$order->addStatusHistoryComment( __("Order Payment Declined by customer") )->save();
				$response_url = $this->base_url . 'checkout/onepage/failure';
				$this->messageManager->addError( __('Order is canceled by customer'));
	
				$response->setUrl($response_url);
				return $response;  

			}
			
			if($data['paymentStatus'] == 'serverError'){
				$response = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);

				$response_url = $this->base_url . 'checkout/onepage/failure';
				$this->messageManager->addError( __('Failed Payment'));
	
				$response->setUrl($response_url);
				return $response;  
			} 

			if ( !isset($_GET['signature']) )
			{
				echo "INVALID REQUEST Something is missing";
				die(1);
			}

			$hash = $this->calculateHash($this->api_key, $data);

			if($hash){
				if($_SERVER['REQUEST_METHOD'] === "GET"){	
					$response = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);

						$order_id = substr($data['merchantOrderId'], 0, -11);
						$order = $this->order->load($order_id);
						
						if(!$order){
							die("Fatal Error: Order with the id of ($order_id) was not found!");
						}

						// ready to invoice
						$already_invoiced = false;
						foreach ($order->getInvoiceCollection() as $invoice) {
								if($invoice->getGrandTotal() == $order->getGrandTotal()){
										$already_invoiced = true;
								}
						}

						if (
		                   $data['paymentStatus'] == 'SUCCESS'
						) {
							
							$grandTotal = $order->getGrandTotal();
							$currency = $order->getOrderCurrencyCode();

							$order->addStatusHistoryComment(__('Successful Payment \r\n Transaction Id: '. $data['transactionId']))->save();

							$invoice = $this->invoice->prepareInvoice($order);
							$invoice->setGrandTotal($grandTotal)
											->setBaseGrandTotal($grandTotal)
											->register()
											->pay()
											->save();

							$order->setState(\Magento\Sales\Model\Order::STATE_PROCESSING)
										->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING)
										->save();

							$response_url = $this->base_url . 'checkout/onepage/success';
						    $this->messageManager->addSuccess( __('Successful Payment \r\n Transaction Id: '. $data['transactionId']));
						
						}else{
							$order->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)
								  ->setStatus(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)->save();
							$order->addStatusHistoryComment( __("Order Payment Declined." . $data['transactionId']) )->save();
							$response_url = $this->base_url . 'checkout/onepage/failure';
    						$this->messageManager->addError( __('Failed Payment \r\n Transaction Id: '. $data['transactionId']));
						}

				 	$response->setUrl($response_url);
				 	return $response;  
				}
			} else {
				echo "This Server is not ready to handle your request right now.";
				die(1);
			}	
		}catch(\Exception $e){
			\var_dump($e);
			echo "====================================";
			echo $e->getMessage();
			echo "====================================";
			die(1);
		}
	}

    public function calculateHash($secret, $data) {
		$queryString = "";
		foreach ($data as $key => $value) { 
			if($key == "signature" || $key== "mode"){
				continue;
			}
			$queryString = $queryString."&".$key."=".$value;
		}
		
		$queryString = ltrim($queryString, $queryString[0]); 
		$signature = hash_hmac( 'sha256' , $queryString , $secret ,false);
		
		if($signature == $data["signature"]){
			return true;
		}else{
			return false;
		}
	}
}
