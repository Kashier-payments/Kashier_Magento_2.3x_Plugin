<?php
namespace Kashier\Payments\Helper;

class Kashier
{
    public $billing;
    public $order_items;
    public $has_delivery;
    public $handles_shipping;
    public $amount;
    public $orderId;
    public $merchantId;
    public $currency;
    public $api_key;
    public $hash;
    public $metaData;


    public function __construct(
        \Magento\Sales\Model\Order $order,
        Array $config
    ) {
        $this->order                = $order;
        $this->api_key              = $config['api_key'];
        $this->merchantId           = $config['merchantId'];
        $this->has_delivery         = $config['has_delivery'];
        $this->handles_shipping     = $config['handles_shipping'];


        $this->set_order_data();
        $this->hash();
    
    }
    
    public function hash(){
        $mid = $this->merchantId;     //your merchant id
        $amount = $this->amount;      //eg: 100
        $currency = $this->currency;  //eg: "EGP"
        $orderId = $this->orderId;    //eg: 99, your system order ID
        $secret = $this->api_key;
        
        $path = "/?payment=".$mid.".".$orderId.".".$amount.".".$currency;
        $this->hash = hash_hmac( 'sha256' , $path , $secret ,false);
    }

    public function set_order_data()
    {

    
        $this->orderId = $this->order->getId() .'_'. time();
        $this->currency  = $this->order->getOrderCurrencyCode();

        if( $this->handles_shipping )
        {
            $amountByMagento = $this->order->getGrandTotal();
            $this->amount = number_format((float) $amountByMagento, 2, '.', '');
        }else{
            $shipping_fees = $this->order->getData()['shipping_amount'];
            $amountByMagento = ($this->order->getGrandTotal() - $shipping_fees);
            $this->amount = number_format((float) $amountByMagento, 2, '.', '');
        }

		$billing_data  = $this->order->getBillingAddress();

        $this->metaData = json_encode([
                                        "CustomerEamil"				=> $this->order->getCustomerEmail(),
                                        "CustomerPhoneNumber"		=> $billing_data->getTelephone(),
                                        "CustomerLastName"			=> str_replace(' ', '-', $billing_data->getLastname()),
                                        "CustomerFirstName"	     	=> str_replace(' ', '-', $billing_data->getFirstname()),
		]);
    }
}
